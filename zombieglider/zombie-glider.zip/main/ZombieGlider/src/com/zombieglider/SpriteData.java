package com.zombieglider;

public class SpriteData{
    public String spriteName;       // name of the sprite
    public int firstFrame;         // number of first frame of this animation in frameData[]
    public int framesCount;        // number of frames in animation
};