package com.zombieglider;

public class FrameData{
    public float x;
    public float y;
    public float rotation;
    public float scaleX;
    public float scaleY;
};