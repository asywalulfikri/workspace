package org.cocos2d.opengl;

public class OpenGLViewCantAttachException extends Exception {
    public OpenGLViewCantAttachException(String reason) {
        super(reason);
    }
}
