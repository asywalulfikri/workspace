package org.cocos2d.types.util;

import org.cocos2d.types.ccQuad2;

public final class ccQuad2Util {
	public static void zero(ccQuad2 q) {
		q.bl_x = 0;
		q.bl_y = 0;
		q.br_x = 0;
		q.br_y = 0;
		q.tl_x = 0;
		q.tl_y = 0;
		q.tr_x = 0;
		q.tr_y = 0;
	}
}
